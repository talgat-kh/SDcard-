//*****************************************************************************
//
//  trial123.h
//
//  Defines and Macros for the SDHost.
//
//  Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
//
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions
//  are met:
//
//    Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//
//    Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the
//    distribution.
//
//    Neither the name of Texas Instruments Incorporated nor the names of
//    its contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
//  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//*****************************************************************************
#include "sdhost_demo.h"
#include "ff.h"
#include "ffconf.h"
#include "diskio.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#ifndef __TRIAL123_H__
#define __TRIAL123_H__

//#define IsUpper(c)  (((c)>='A')&&((c)<='Z'))
//#define IsLower(c)  (((c)>='a')&&((c)<='z'))
//#define IsDigit(c)  (((c)>='0')&&((c)<='9'))

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

typedef struct {
  FIL* fp;
  int idx, nchr;
  BYTE buf[64];
} putbuff;

//*****************************************************************************
//
// API Function prototypes
//
//*****************************************************************************
extern unsigned long SendCmd(unsigned long ulCmd, unsigned long ulArg);
extern unsigned long long CardCapacityGet(unsigned short ulRCA);
extern unsigned long CardInit(CardAttrib_t *CardAttrib);
extern unsigned long CardSelect(CardAttrib_t *Card);
extern void CardDeselect();
extern unsigned long CardReadBlock(CardAttrib_t *Card, unsigned char *pBuffer, unsigned long ulBlockNo, unsigned long ulBlockCount);
extern unsigned long CardWriteBlock(CardAttrib_t *Card, unsigned char *pBuffer, unsigned long ulBlockNo, unsigned long ulBlockCount);
extern void BoardInit(void);
extern void ListDirectory(DIR *dir);
extern int str_append(char **json, const char *format, ...);
extern FRESULT open_append(FIL* fp, const char* path);

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif // __TRIAL123_H__

